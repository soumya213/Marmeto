const mongoose=require('mongoose')
const Schema=mongoose.Schema

let voucherSchema={
    code:{
        type:'String',
        unique: true,
    },
    pin:{
        type:'String',
        unique: true,
    },
    email:{
        type:'String',
        default:''
    },
    amount:{
        type:Number,
        default:0
    },
    generationTime:{
        type:Date,
        default:Date.now()
    },
    usage_activity:{
        type:Date,
        default:''
    },
    status:{
        type:'String',
        default:'InActive'
    },
    count:{
        type:Number,
        default:0
    }
}


mongoose.model('VoucherModel',voucherSchema)