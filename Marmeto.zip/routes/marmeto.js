const express = require('express')
const controller=require('./../controllers/marmetoController')
const authenticate=require('../libs/tokenLibs')

// "tokenDetails": {
//     "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6InNvdW15YSIsImVtYWlsIjoic291bXlhLmRoYXJAZ21haWwuY29tIiwiaWF0IjoxNTkzMDgyMDgyfQ.y9rX3kVqPrvccjXRuRa9DldWDHhkhUm2oANsu18KEKU",
//     "tokenSecret": "secretKey"
// }

let setRouter = (app) => {
    //used to generate token details . Token detail is given above
    app.post('/login',authenticate.generateToken)

    //Body parameter which needed to be passed are email,amount and authToken
    app.post('/createVoucher',authenticate.verifyClaim,controller.createVoucher)

    //Search by Email 
    app.get('/search/:email',controller.viewVoucherbyEmail)

    //Body parameter which needed to passed are pin,email and amount that is to redeemed
    app.post('/voucherRedeem',controller.voucherRedeem)

}


module.exports={
    setRouter:setRouter
}