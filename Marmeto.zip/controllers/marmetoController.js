
const express = require('express')
const mongoose = require('mongoose')
const model = require('../models/marmetoModel')
const randomstring = require("randomstring");

const VoucherModel = mongoose.model('VoucherModel')

let testing = (req, res) => { res.send(' Application Working fine ') }


let createVoucher = (req, res) => {
    console.log("Getting inside");
    
    let generationTime = Date.now();
    let voucherCode = 'VCD' + randomstring.generate(10);
    let Voucherpin = randomstring.generate(5);
    let newVoucher = new VoucherModel({
        code: voucherCode,
        pin: Voucherpin,
        email: req.body.email,
        amount: req.body.amount,
        generationTime: generationTime,
        status: "Active"
    })
    newVoucher.save((err, result) => {
        if (err) {
            console.log(err);
            res.send(err)
        } else {
            res.send(result)
        }
    })

}

//searchByEmail
let viewVoucherbyEmail = (req, res) => {
    VoucherModel.find({ 'email': req.params.email }, (err, result) => {
        if (err) {
            console.log(err);
            res.send(err)
        } else if (result == undefined || result == null || result == '') {
            console.log('No voucher Found');
            res.send('No voucher Found')
        }
        else {
            res.send(result)
        }
    })
}


//Redeem Voucher
let voucherRedeem = (req, res) => {
    VoucherModel.find({ 'email': req.body.email, 'pin': req.body.pin }, (err, result) => {
        if (err) {
            console.log(err);
            res.send(err)
        } else if (result == undefined || result == null || result == '') {
            console.log('No Voucher Found');
            res.send('No Voucher Found')
        }
        else {

            if (result[0].status === 'Inactive' || result[0].status === 'Redeemed') {
                return res.send({
                    message: 'This voucher is not longer valid or it is been used'
                 });  
            }

            voucherValidity= (Date.now()-result[0].generationTime)/3600000
            console.log(voucherValidity);
            
            if (voucherValidity > 24) {
                result[0].status = 'Inactive'
                saveData(result[0])
            }
            //If The voucher is accessed less than 10 min it will fail and if count more than five it will fail
            let timediff = 0
            result[0].usage_activity=Date.now()
            amountDiff=result[0].amount - req.body.amount
            timediff = (result[0].usage_activity - result[0].generationTime) / 60000;
            if ( result[0].count < 5 && amountDiff > 0 && result[0].usage_activity != null && timediff > 10) {
                result[0].count +=1
                result[0].amount -= req.body.amount
                result[0].status = 'Partially Redeemed'
            }
            else {
                result[0].status = 'Redeemed'
            }   
            
            result[0].save(function(err,result){
                if(err){
                    console.log(err);
                    return res.send(err)
                }
                else{
                    console.log('Voucher updated Successfully');
                    return res.send(result)
                }
            }) 
        }
    })
}

module.exports = {
    testing:testing,
    createVoucher: createVoucher,
    viewVoucherbyEmail: viewVoucherbyEmail,
    voucherRedeem: voucherRedeem
}